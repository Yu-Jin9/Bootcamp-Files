package com.study.ExCalc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExCalcApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExCalcApplication.class, args);
	}

}
