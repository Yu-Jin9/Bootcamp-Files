package com.study.ExCalc;

import lombok.Data;

@Data
public class ResDTO {
    private String status;
    private String message;
    private int result;
}
