package com.study.ExCalc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExCalcApplicationTests {

	@Test
	void contextLoads() {
	}

}
